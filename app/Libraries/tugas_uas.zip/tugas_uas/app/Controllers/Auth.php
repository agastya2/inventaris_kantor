<?php

namespace App\Controllers;

class Auth extends BaseController
{
    public function index()
    {
        // Menampilkan view login
        return view('auth/login');
    }

    public function doLogin()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        if ($username === 'admin' && $password === 'admin') {
            return redirect()->to('/dashboard');
        }

        return redirect()->back()->with('error', 'Username atau password salah!');
    }
}