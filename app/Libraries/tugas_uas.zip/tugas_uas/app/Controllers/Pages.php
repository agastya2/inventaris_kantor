<?php

namespace App\Controllers;

use App\Libraries\DummyData;

class Pages extends BaseController
{

    public function dashboard()
    {
        return view('pages/dashboard');
    }
//    public function barang()
//    {
//        return view('pages/barang');
//    }

//    public function peminjaman()
//    {
//        return view('pages/peminjaman');
//    }

    public function barang()
    {
        $data['barangList'] = DummyData::getBarang();
        return view('pages/barang', $data);
    }

    public function peminjaman()
    {
        $peminjamanList = DummyData::getPeminjaman();
        return view('pages/peminjaman', compact('peminjamanList'));
    }

}