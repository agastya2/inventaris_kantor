<?= $this->include('layouts/header') ?>

<div id="wrapper">

    <?= $this->include('layouts/sidebar') ?>

    <div id="content-wrapper" class="d-flex flex-column">

        <div id="content">
            <div class="container-fluid">
                <h1 class="h3 mb-4 text-gray-800">Peminjaman</h1>
                <p class="text-dark">Data peminjaman barang.</p>

                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Tabel Peminjaman</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Peminjam</th>
                                    <th>Nama Barang</th>
                                    <th>Tanggal Pinjam</th>
                                    <th>Tanggal Kembali</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if (isset($peminjamanList)): ?>
                                    <?php foreach ($peminjamanList as $index => $pinjam): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= $pinjam['nama'] ?></td>
                                            <td><?= $pinjam['barang'] ?></td>
                                            <td><?= $pinjam['tanggal_pinjam'] ?></td>
                                            <td><?= $pinjam['tanggal_kembali'] ?></td>
                                            <td><?= $pinjam['status'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Data tidak tersedia.</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <?= $this->include('layouts/footer') ?>
    </div>

</div>
