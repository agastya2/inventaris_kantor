<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::index');              // tampilan awal login
$routes->get('/login', 'Auth::index');         // login juga pakai view yg sama
$routes->post('/login', 'Auth::doLogin');      // proses login
$routes->get('/dashboard', 'Pages::dashboard');
$routes->get('/barang', 'Pages::barang');
$routes->get('/peminjaman', 'Pages::peminjaman');
$routes->get('/logout', 'Auth::index');

